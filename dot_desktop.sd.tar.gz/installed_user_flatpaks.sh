flatpak install --user com.spotify.Client -y
